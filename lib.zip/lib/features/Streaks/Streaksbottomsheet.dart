import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:glassmorphism/glassmorphism.dart';
import 'package:second_chat/core/constants/app_colors/app_colors.dart';
import 'package:second_chat/core/themes/textstyles.dart';
import 'package:second_chat/core/widgets/custom_switch.dart';

import '../../controllers/Main Section Controllers/streak_controller.dart';
import 'Freeze_bottomsheet.dart';

class StreamStreakSetupBottomSheet extends StatelessWidget {
  const StreamStreakSetupBottomSheet({super.key});

  @override
  Widget build(BuildContext context) {
    final controller = Get.put(StreamStreaksController());

    return Container(
      height: Get.height * 0.9,
      decoration: BoxDecoration(
        color: bottomSheetGrey,
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(18),
          topRight: Radius.circular(18),
        ),
      ),
      child: Stack(
        children: [
          Column(
            children: [
              SizedBox(height: 12.h),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.w),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    InkWell(
                      onTap: () {
                        controller.isSelectingThreeDays.value = false;
                        controller.threeTimesWeek.value = false;
                        controller.selectedMenuNumbers.clear();
                        Get.back();
                      },
                      child: Image.asset(
                        'assets/icons/x_icon.png',
                        height: 44.h,
                        errorBuilder: (_, __, ___) =>
                            Icon(Icons.close, color: Colors.white, size: 44.h),
                      ),
                    ),
                    Text(
                      "Stream Streaks",
                      style: TextStyle(
                        fontSize: 17.sp,
                        fontWeight: FontWeight.w700,
                        color: Colors.white,
                      ),
                    ),
                    SizedBox(width: 44.w),
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  padding: EdgeInsets.symmetric(horizontal: 20.w),
                  child: Column(
                    children: [
                      SizedBox(height: 10.h),
                      Container(
                        child: Image.asset(
                          'assets/images/abc.png',
                          height: 177.h,
                        ),
                      ),
                      SizedBox(height: 6.h),
                      Text(
                        "Build a long-term habit",
                        style: sfProDisplay600(22.sp, Colors.white),
                      ),
                      SizedBox(height: 4.h),
                      Text(
                        "Settings a streak goals  helps you stay consistent",
                        style: sfProDisplay400(15.sp, Color(0xFFB0B3B8)),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 14.h),
                      _buildDayToggles(controller),
                      SizedBox(height: 14.h),
                      _buildDivider(),
                      SizedBox(height: 10.h),
                      _buildThreeTimesOption(controller),
                      SizedBox(height: 100.h), // Extra space for scrolling
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(16.w),
                child: SizedBox(
                  height: 50.h,
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: () {
                      Get.bottomSheet(
                        const StreakFreezePreviewBottomSheet(),
                        isScrollControlled: true,
                        ignoreSafeArea: false,
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(36.r),
                      ),
                    ),
                    child: Text(
                      "Next",
                      style: sfProText600(17.sp, Colors.black),
                    ),
                  ),
                ),
              ),
            ],
          ),

          // Glow effect above the header text - positioned to extend upward
          Positioned(
            top: 0.h + 4.h + 0.h + 68.5.h, // Center of image position
            left: 0,
            right: 0,
            child: IgnorePointer(
              child: Center(
                child: Container(
                  width: 177.h, // Match image width
                  height: 177.h, // Match image height
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Color(0XFFFFE6A7).withOpacity(0.2),
                        blurRadius: 40,
                        spreadRadius: 10,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),

          Obx(() {
            if (!controller.isSelectingThreeDays.value) {
              return const SizedBox.shrink();
            }

            return Positioned.fill(
              child: GestureDetector(
                onTap: () => controller.isSelectingThreeDays.value = false,
                behavior: HitTestBehavior.opaque,
                child: Container(
                  color: Colors.transparent, // Capture taps to close
                  child: Stack(
                    children: [
                      Positioned(
                        bottom:
                            145.h, // Positioned right above the "3-times" bar
                        left: 16.w, // From Figma: left: 16px
                        child: Obx(() {
                          return GlassmorphicContainer(
                            width: 90, // Fixed width from Figma
                            height: 352, // Fixed height from Figma
                            borderRadius: 22.r,
                            blur: 10, // Premium glass effect blur
                            alignment: Alignment.center,
                            border: 1,
                            linearGradient: LinearGradient(
                              begin: Alignment.centerLeft,
                              end: Alignment.centerRight,
                              colors: [
                                const Color(
                                  0xFF000000,
                                ).withOpacity(0.06), // Glass base layer
                                const Color(
                                  0xFF000000,
                                ).withOpacity(0.6), // Consistent opacity
                              ],
                              stops: const [0.0, 1.0],
                            ),
                            borderGradient: LinearGradient(
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                              colors: [
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.1), // Design spec border
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.8),
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.6),
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.6),
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.5),
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.4),
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.03),
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.02),
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.01),
                                const Color.fromARGB(
                                  255,
                                  141,
                                  141,
                                  150,
                                ).withOpacity(0.01),
                              ],
                              stops: const [
                                0.1,
                                0.2,
                                0.3,
                                0.4,
                                0.5,
                                0.6,
                                0.7,
                                0.8,
                                0.9,
                                1,
                              ],
                            ),
                            child: SingleChildScrollView(
                              physics: const ClampingScrollPhysics(),
                              child: Padding(
                                padding: EdgeInsets.symmetric(vertical: 14.h),
                                child: Column(
                                  children: [
                                    ...controller.selectedMenuNumbers.map(
                                      (n) => GestureDetector(
                                        onTap: () =>
                                            controller.toggleMenuNumber(n),
                                        child: Padding(
                                          padding: EdgeInsets.symmetric(
                                            vertical: 6.h,
                                          ),
                                          child: Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            children: [
                                              Icon(
                                                Icons.check,
                                                size: 18.sp,
                                                color: Colors.white,
                                              ),
                                              SizedBox(width: 6.w),
                                              Text(
                                                "$n",
                                                style: TextStyle(
                                                  fontSize: 20.sp,
                                                  fontWeight: FontWeight.w600,
                                                  color: Colors.white,
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                    if (controller
                                        .selectedMenuNumbers
                                        .isNotEmpty) ...[
                                      SizedBox(height: 12.h),
                                      Container(
                                        height: 1,
                                        width: 40.w,
                                        color: Colors.white.withOpacity(0.15),
                                      ),
                                      SizedBox(height: 12.h),
                                    ],
                                    ...controller.availableMenuNumbers.map(
                                      (n) => GestureDetector(
                                        onTap: () =>
                                            controller.toggleMenuNumber(n),
                                        child: Padding(
                                          padding: EdgeInsets.symmetric(
                                            vertical: 6.h,
                                          ),
                                          child: Text(
                                            "$n",
                                            style: TextStyle(
                                              fontSize: 18.sp,
                                              color: const Color(0xFF8E8E93),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          );
                        }),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }),
        ],
      ),
    );
  }

  Widget _buildDayToggles(StreamStreaksController controller) {
    final days = controller.selectedDays.keys.toList();
    return Column(
      children: [
        _row(controller, days[0], days[1]),
        SizedBox(height: 16.h),
        _row(controller, days[2], days[3]),
        SizedBox(height: 16.h),
        _row(controller, days[4], days[5]),
        SizedBox(height: 16.h),
        _toggle(controller, days[6]),
      ],
    );
  }

  Widget _row(StreamStreaksController c, String d1, String d2) {
    return Row(
      children: [
        Expanded(child: _toggle(c, d1)),
        SizedBox(width: 16.w),
        Expanded(child: _toggle(c, d2)),
      ],
    );
  }

  Widget _toggle(StreamStreaksController c, String day) {
    return Obx(() {
      final selected = c.selectedDays[day]!;
      final disabled = c.areDaysDisabled;

      return AnimatedOpacity(
        opacity: disabled ? 0.4 : 1,
        duration: const Duration(milliseconds: 200),
        child: Container(
          height: 52.h,
          padding: EdgeInsets.symmetric(horizontal: 12.w),
          decoration: BoxDecoration(
            color: const Color(0xFF1C1C1E),
            borderRadius: BorderRadius.circular(18.r),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                day,
                style: sfProText400(
                  17.sp,
                  selected ? Colors.white : const Color(0xFF8E8E93),
                ),
              ),
              CustomSwitch(
                value: selected,
                onChanged: disabled ? null : (_) => c.toggleDay(day),
              ),
            ],
          ),
        ),
      );
    });
  }

  Widget _buildDivider() {
    return Row(
      children: [
        Expanded(child: Container(height: 1, color: const Color(0xFF2C2C2E))),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16.w),
          child: Text(
            'OR',
            style: sfProText400(13.sp, const Color(0xFF8E8E93)),
          ),
        ),
        Expanded(child: Container(height: 1, color: const Color(0xFF2C2C2E))),
      ],
    );
  }

  Widget _buildThreeTimesOption(StreamStreaksController controller) {
    return Obx(() {
      final selected = controller.threeTimesWeek.value;
      return GestureDetector(
        onTap: () {
          controller.toggleThreeTimesWeek(!selected);
          // Toggle menu visibility when clicking the row
          if (!selected) {
            controller.isSelectingThreeDays.value = true;
          }
        },
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
          decoration: BoxDecoration(
            color: const Color(0xFF1C1C1E),
            borderRadius: BorderRadius.circular(14.r),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Image.asset('assets/images/Pop-up Menu Indicator.png'),
                  SizedBox(width: 12.w),
                  Text(
                    '3-times a week',
                    style: sfProText400(
                      17.sp,
                      selected ? Colors.white : const Color(0xFF8E8E93),
                    ),
                  ),
                ],
              ),
              CustomSwitch(
                value: selected,
                onChanged: (val) {
                  controller.toggleThreeTimesWeek(val);
                  if (val) controller.isSelectingThreeDays.value = true;
                },
              ),
            ],
          ),
        ),
      );
    });
  }
}
